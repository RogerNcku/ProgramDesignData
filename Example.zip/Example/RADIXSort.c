#include <stdio.h>
//#include "sort.h"

#define SIZE 10
#define RADIX 10

/* �L�X�}�C */
static void printArray_radix(int arr[], int n) {
    int i;
    for (i = 0; i < n; i++) {
        if (i > 0) printf(" -> ");
        printf("%d", arr[i]);
    }
    printf("\n");
}

/* �@�� pass�G�� exp ��ư����t�P���� */
static void onePass(int arr[], int n, int exp, const char* title) {
    int buckets[RADIX][SIZE];
    int count[RADIX] = { 0 };
    int i, j, k, digit;

    printf("\n%s\n", title);

    /* ��J���� bucket */
    for (i = 0; i < n; i++) {
        digit = (arr[i] / exp) % 10;
        buckets[digit][count[digit]] = arr[i];
        count[digit]++;
    }

    /* �L�X�C�� bucket */
    for (i = 0; i < RADIX; i++) {
        printf("digit[%d] -> ", i);
        for (j = 0; j < count[i]; j++) {
            if (j > 0) printf(" -> ");
            printf("%d", buckets[i][j]);
        }
        printf("\n");
    }

    /* �����^��}�C */
    k = 0;
    for (i = 0; i < RADIX; i++) {
        for (j = 0; j < count[i]; j++) {
            arr[k++] = buckets[i][j];
        }
    }

    /* �L�X�o�@���Ƨǫᵲ�G */
    printf("\nCurrent array:\n");
    printArray_radix(arr, n);
}

/* Radix Sort */
void radixSort(int arr[], int n) {
    onePass(arr, n, 1, "Insert number using the last digit (�Ӧ�)");
    onePass(arr, n, 10, "Insert number using the second digit (�Q��)");
    onePass(arr, n, 100, "Insert number using the first digit (�ʦ�)");
}

/* �� main.c �I�s�� demo */
void runRadixSortDemo(void) {
    int A[SIZE] = { 179, 208, 306, 93, 859, 984, 55, 9, 271, 33 };

    printf("Original:\n");
    printArray_radix(A, SIZE);

    radixSort(A, SIZE);

    printf("\nFinal sorted:\n");
    printArray_radix(A, SIZE);
}